module.exports = {
    apps: [
      {
        name: 'Fantacy_App',
        script: 'app.js',  // Change this to the entry file of your Node.js application
        watch: true,
      },
      // Add more app configurations if needed
    ],
  };
  